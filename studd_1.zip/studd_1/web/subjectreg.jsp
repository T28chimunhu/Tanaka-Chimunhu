<%-- 
    Document   : index
    Created on : Mar 13, 2024, 10:26:15 AM
    Author     : Tanaka
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*" %> 

<% 

if(request.getParameter("submit") !=null)

{ 

String year = request.getParameter("year");
String level = request.getParameter("level");
String paymentdate = request.getParameter("paymentdate");
String moduleid = request.getParameter("moduleid");
String course = request.getParameter("course");
String amount = request.getParameter("amount");

Connection con;
PreparedStatement pst;
ResultSet rs;
Class.forName("com.mysql.jdbc.Driver");
con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","1234");
pst = con.prepareStatement("insert into addpayment(year,level,paymentdate,module_id,course,amount) values(?,?,?,?,?,?)");
pst.setString(1, year);
pst.setString(2, level);
pst.setString(3, paymentdate);
pst.setString(4, moduleid);
pst.setString(5, course);
pst.setString(6, amount);
pst.executeUpdate();

%>
<script>
    Alert("Record Adedddd");
</script>


<%
}




%>


<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link href="bootstrap-5.3.3-dist/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap-5.3.3-dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
    <div class="card">
    <div class="card-header">
    <center> <h1>REGISTER MODULE AND PAY FEES</h1></center>
    </div>
           <div class="card-body">
          <div class="row mb-3">
        <div class="container text-center">
                <form  method="post" action="#">
                     <div class="row">
                      <div class="col">
                      <div alight ='left'>
                        <label class="form-label"> Year</label>
                        <select class="form-select" aria-label="Default select example" name="year" id="year" >
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                         <option value="4">4</option>
                         </select>
                       </div>
                      </div>
                      <div class="col">
                      <div alight ='left'>
                        <label class="form-label"> Level</label>
                      <select class="form-select" aria-label="Default select example" name="level" id="level" >
                        <option value="1">1</option>
                        <option value="2">2</option>
                        </select>
                    </div>
                      </div>
                     </div>
             <div class="row">
                  <div class="col">
                    <div alight ='left'>
                        <label class="form-label"> Payment Date</label>
                        <input type='text' class='form-control' placeholder="Date Paid (yyyy-mm-dd)" name='paymentdate' id="paymentdate" required> 
                    </div>
                  </div>  
                      <div class="col">
                         <div alight ='left'>
                        <label class="form-label"> Module Code</label>
                        <input type='cell' class='form-control' placeholder="module code" name='moduleid' id="moduleid" required> 
                    </div>
                      </div>
             </div>
               <div class="row">
                <div class="col">
                    <div alight ='left'>
                        <label class="form-label"> Course</label>
                        <input type='text' class='form-control' placeholder="course" name='course' id="course" required> 
                    </div>
                </div>
                 <div class="col">                    
                    <div alight ='left'>
                        <label class="form-label"> Amount</label>
                        <input type='text' class='form-control' placeholder="amount paid" name='amount' id="amount" required> 
                    </div>
                 </div>
               </div>
                            
                    <div alight ='right'>
                        <input type="submit" id="submit" value="submit" name="submit" class='btn btn-info'>
                        <input type="reset" id="reset" value="reset" name="reset" class='btn btn-warning'>
                    </div>       
                </form>
                
            </div>
              <div class="row">
            <div class="col-sm">
                <div class="panel-body">
                    <div class="p-3 text-primary-emphasis bg-secondary-subtle border border-primary-subtle rounded-3">
                    <table id="tbl-student" class="table table-responsive table-bordered" cellpadding='0' width='100%'>
                        <thead>
                            <tr> 
                                <th>Year</th>
                                <th> Level</th>
                                <th>Payment Date</th>
                                <th> Module Code</th>
                                <th> Course</th>
                                <th> Amount</th>
                                <th> Edit</th>
                                <th> Delete</th>
                            </tr>
                        
                            <%
                            Connection con;
                            PreparedStatement pst;
                            ResultSet rs;
                            Class.forName("com.mysql.jdbc.Driver");
                            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","1234");

                            String query = "select* from addpayment";
                            Statement st = con.createStatement();
                            rs = st.executeQuery(query);
                            while(rs.next())
                            {
                                String id = rs.getString("id");
                                
                             
                               %> 
                            <tr> 
                                <td><%=rs.getString("year")%></td>
                                <td><%=rs.getString("level")%></td>
                                <td><%=rs.getString("paymentdate")%> </td>
                                <td> <%=rs.getString("module_id")%></td>
                                <td><%=rs.getString("Course")%></td>
                                <td><%=rs.getString("amount")%> </td>
                                <td><a href="editmodule.jsp?id=<%=id%>">Edit</a> </td>
                                <td><a href="deletemodule.jsp?id=<%=id%>">Delete </a></td>
                            </tr>
                            <%
                             } 
                            %>
                    </table>
                     <p><a href="login.html"> Click Back</a></p>
            </div>
                </div>
        </div>
        </div>
    </body>
</html>

