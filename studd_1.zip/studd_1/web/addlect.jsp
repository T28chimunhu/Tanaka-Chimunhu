<%-- 
    Document   : index
    Created on : Mar 13, 2024, 10:26:15 AM
    Author     : Tanaka
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*" %> 

<% 

if(request.getParameter("submit") !=null)

{ 

String name = request.getParameter("lname");
String contact = request.getParameter("phone");
String address = request.getParameter("address");
String course = request.getParameter("course");
String courseid = request.getParameter("courseid");

Connection con;
PreparedStatement pst;
ResultSet rs;
Class.forName("com.mysql.jdbc.Driver");
con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","1234");
pst = con.prepareStatement("insert into addlec(lname,phone,address,course,course_id) values(?,?,?,?,?)");
pst.setString(1, name);
pst.setString(2, contact);
pst.setString(3, address);
pst.setString(4, course);
pst.setString(5, courseid);
pst.executeUpdate();

%>
<script>
    Alert("Record Adedddd");
</script>


<%
}




%>


<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link href="bootstrap-5.3.3-dist/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap-5.3.3-dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
    <center> <h1>LECTURER INFORMATION</h1></center>
        </br>
        <div class="container text-center">
        <div class="row">
            <div class="col-sm-4">
                <form  method="post" action="#">
                    <div alight ='left'>
                        <label class="form-label"> Lecturer Name</label>
                        <input type='text' class='form-control' placeholder="Lecturer Name" name='lname' id="lname" required> 
                    </div>
                            </br>
                         <div alight ='left'>
                        <label class="form-label"> Contact</label>
                        <input type='cell' class='form-control' placeholder="Phone Number" name='phone' id="phone" required> 
                    </div>
                            </br>
                    <div alight ='left'>
                        <label class="form-label"> Address</label>
                        <input type='text' class='form-control' placeholder="address" name='address' id="address" required> 
                    </div>
                            </br>        
                    <div alight ='left'>
                        <label class="form-label"> Course</label>
                        <input type='text' class='form-control' placeholder="Course" name='course' id="course" required> 
                    </div> 
                            </br>
                     <div alight ='left'>
                        <label class="form-label"> Course Id</label>
                        <input type='text' class='form-control' placeholder="Course Id" name='courseid' id="courseid" required> 
                    </div> 
                            </br>
                    <div alight ='right'>
                        <input type="submit" id="submit" value="submit" name="submit" class='btn btn-info'>
                        <input type="reset" id="reset" value="reset" name="reset" class='btn btn-warning'>
                    </div>       
                </form>
                
            </div>
            
            <div class="col-sm-8">
                <div class="panel-body">
                    <div class="p-3 text-primary-emphasis bg-primary-subtle border border-primary-subtle rounded-3">
                    <table id="tbl-student" class="table table-responsive table-bordered" cellpadding='0' width='100%'>
                        <thead>
                            <tr> 
                                <th>Lecturer Name </th>
                                <th> Contact</th>
                                <th> Address</th>
                                <th> Course</th>
                                <th> Course ID</th>
                                <th> Edit</th>
                                <th> Delete</th>
                            </tr>
                        
                            <%
                            Connection con;
                            PreparedStatement pst;
                            ResultSet rs;
                            Class.forName("com.mysql.jdbc.Driver");
                            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","1234");

                            String query = "select* from addlec";
                            Statement st = con.createStatement();
                            rs = st.executeQuery(query);
                            while(rs.next())
                            {
                                String id = rs.getString("id");
                                
                             
                               %> 
                            <tr> 
                                <td><%=rs.getString("lname")%></td>
                                <td><%=rs.getString("phone")%> </td>
                                <td> <%=rs.getString("address")%></td>
                                <td><%=rs.getString("course")%></td>
                                <td><%=rs.getString("course_id")%> </td>
                                <td><a href="updatelec.jsp?id=<%=id%>">Edit</a> </td>
                                <td><a href="deletelec.jsp?id=<%=id%>">Delete </a></td>
                            </tr>
                            <%
                             } 
                            %>
                    </table>
            </div>
                </div>
                    <p><a href="registration.html"> Click Back</a></p>
        </div>
        </div>
    </body>
</html>

