<%-- 
    Document   : delete
    Created on : Mar 13, 2024, 1:26:21 PM
    Author     : Tanaka
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%@page import="java.sql.*" %> 

<%  
    
String id = request.getParameter("id");
Connection con;
PreparedStatement pst;
ResultSet rs;
Class.forName("com.mysql.jdbc.Driver");
con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","1234");
pst = con.prepareStatement("delete from addpayment where id=? ");
pst.setString(1, id);
pst.executeUpdate();

%>

<script>
    Alert("Record Deleted");
</script>
