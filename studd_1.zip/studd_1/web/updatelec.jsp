

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*" %> 

<% 

if(request.getParameter("submit") !=null)

{ 
    
String id = request.getParameter("id");
String name = request.getParameter("lname");
String contact = request.getParameter("phone");
String address = request.getParameter("address");
String course = request.getParameter("course");
String courseid = request.getParameter("courseid");



Connection con;
PreparedStatement pst;
ResultSet rs;
Class.forName("com.mysql.jdbc.Driver");
con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","Tanaka1996*#");
pst = con.prepareStatement("update addlec set lname=?, phone=?, address=?, course=?, course_id=? where id=?");
pst.setString(1, name);
pst.setString(2, contact);
pst.setString(3, address);
pst.setString(4, course);
pst.setString(5, courseid);
pst.setString(6, id);
pst.executeUpdate();
%>
<script>
    Alert("Record Updated");
</script>


<%
}




%>



<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link href="bootstrap-5.3.3-dist/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap-5.3.3-dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
    <center> <h1>LECTURER INFORMATION</h1></center>
        </br>
        <div class="container text-center">
        <div class="row">
            <div class="col-sm-4">
                <form  method="post" action="#">
                   
                    <%
                    Connection con;
                    PreparedStatement pst;
                    ResultSet rs;
                    Class.forName("com.mysql.jdbc.Driver");
                    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","Tanaka1996*#");

                    String id = request.getParameter("id");
                    pst = con.prepareStatement("select * from addlec where id=?");
                    pst.setString(1,id);
                    rs= pst.executeQuery();
                    
                    while(rs.next())
                    {

                    %>
               
                    <div alight ='left'>
                        <label class="form-label"> Lecturer Name</label>
                        <input type='text' class='form-control' placeholder="Lecturer Name" value='<%=rs.getString("lname") %>' name='lname' id="lname" required> 
                    </div>
                            </br>
                         <div alight ='left'>
                        <label class="form-label"> Contact</label>
                        <input type='cell' class='form-control' placeholder="Phone Number" value='<%=rs.getString("phone") %>' name='phone' id="phone" required> 
                    </div>
                            </br>
                    <div alight ='left'>
                        <label class="form-label"> Address</label>
                        <input type='text' class='form-control' placeholder="address" value='<%=rs.getString("address") %>' name='address' id="address" required> 
                    </div>
                            </br>        
                    <div alight ='left'>
                        <label class="form-label"> Course</label>
                        <input type='text' class='form-control' placeholder="Course" value='<%=rs.getString("course") %>' name='course' id="course" required> 
                    </div> 
                            </br>
                     <div alight ='left'>
                        <label class="form-label"> Course Id</label>
                        <input type='text' class='form-control' placeholder="Course Id" value='<%=rs.getString("course_id") %>' name='courseid' id="courseid" required> 
                    </div> 
                     <%
                        }
                        %>
                            </br>
                    <div alight ='right'>
                        <input type="submit" id="submit" value="submit" name="submit" class='btn btn-info'>
                        <input type="reset" id="reset" value="reset" name="reset" class='btn btn-warning'>
                    </div>       
                </form>
                
            </div>
        </div>
         </body>
       </html>