
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*" %> 

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link href="bootstrap-5.3.3-dist/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap-5.3.3-dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
    <div class="card">
    <div class="card-header">
    <center> <h1>Upload Assignment</h1></center>
    </div>
           <div class="card-body">
          <div class="row mb-3">
        <div class="container text-center">
<div class="row">
            <div class="col-sm">
                <div class="panel-body">
                    <div class="p-3 text-primary-emphasis bg-secondary-subtle border border-primary-subtle rounded-3">
                    <table id="tbl-student" class="table table-responsive table-bordered" cellpadding='0' width='100%'>
                        <thead>
                            <tr> 
                                <th>Year</th>
                                <th> Level</th>
                                <th>Module</th>
                                <th> Module Code</th>
                                <th> Course</th>
                                <th> Lecturer</th>
                                <th> Upload Assignment</th>
                                <th> View/Download Assignment</th>
                            </tr>
                        
                            <%
                            Connection con;
                            PreparedStatement pst;
                            ResultSet rs;
                            Class.forName("com.mysql.jdbc.Driver");
                            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","Tanaka1996*#");

                            String query = "select* from addsub";
                            Statement st = con.createStatement();
                            rs = st.executeQuery(query);
                            while(rs.next())
                            {
                                String id = rs.getString("id");
                                
                             
                               %> 
                            <tr> 
                                <td><%=rs.getString("year")%></td>
                                <td><%=rs.getString("level")%></td>
                                <td><%=rs.getString("module")%> </td>
                                <td> <%=rs.getString("module_id")%></td>
                                <td><%=rs.getString("Course")%></td>
                                <td><%=rs.getString("Lecturer")%> </td>
                                <td><a href="fileupload.html?id=<%=id%>">Upload Assignment</a> </td>
                                <td><a href="file1.jsp?id=<%=id%>">View/Download Assignment</a> </td>
                            </tr>
                            <%
                             } 
                            %>
                    </table>
                     <p><a href="registration.html"> Click Back</a></p>
            </div>
                </div>
        </div>
        </div>
    </body>
</html>

