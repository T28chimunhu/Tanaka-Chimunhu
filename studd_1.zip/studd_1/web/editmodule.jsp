<%--  
    Document   : update
    Created on : Mar 13, 2024, 1:26:06 PM
    Author     : Tanaka
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*" %> 

<% 

if(request.getParameter("submit") !=null)

{ 
    
String id = request.getParameter("id");
String year = request.getParameter("year");
String level = request.getParameter("level");
String paymentdate = request.getParameter("paymentdate");
String moduleid = request.getParameter("moduleid");
String course = request.getParameter("course");
String amount = request.getParameter("amount");

Connection con;
PreparedStatement pst;
ResultSet rs;
Class.forName("com.mysql.jdbc.Driver");
con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","1234");
pst = con.prepareStatement("update addpayment set year=?, level=?, paymentdate=?, module_id=?, course=?, amount=? where id=?");
pst.setString(1, year);
pst.setString(2, level);
pst.setString(3, paymentdate);
pst.setString(4, moduleid);
pst.setString(5, course);
pst.setString(6, amount);
pst.setString(7, id);
pst.executeUpdate();
%>
<script>
    Alert("Record Updated");
</script>


<%
}

%>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link href="bootstrap-5.3.3-dist/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap-5.3.3-dist/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
    <div class="card">
    <div class="card-header">
    <center> <h1>ALTER PAYMENT DETAILS</h1></center>
    </div>
           <div class="card-body">
          <div class="row mb-3">
        <div class="container text-center">
                <form  method="post" action="#">  
                    <%
                    Connection con;
                    PreparedStatement pst;
                    ResultSet rs;
                    Class.forName("com.mysql.jdbc.Driver");
                    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","1234");
                    String id = request.getParameter("id");
                    pst = con.prepareStatement("select * from addpayment where id=?");
                    pst.setString(1,id);
                    rs= pst.executeQuery();
                    
                    while(rs.next())
                    {
                    %>
                       <div class="row">
                      <div class="col">
                      <div alight ='left'>
                        <label class="form-label"> Year</label>
                        <select class="form-select" aria-label="Default select example"  name="year" id="year" >
                        <option><%= rs.getString("year")%></option>
                       <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                         <option value="4">4</option>
                         </select>
                       </div>
                      </div>
                      <div class="col">
                      <div alight ='left'>
                        <label class="form-label"> Level</label>
                      <select class="form-select" aria-label="Default select example"  name="level" id="level" >
                         <option><%= rs.getString("level")%></option>
                          <option value="1">1</option>
                        <option value="2">2</option>
                        </select>
                    </div>
                      </div>
                     </div>
             <div class="row">
                  <div class="col">
                    <div alight ='left'>
                        <label class="form-label"> Payment Date</label>
                        <input type='text' class='form-control' placeholder="paymentdate" value='<%=rs.getString("paymentdate") %>' name='paymentdate' id="paymentdate" required> 
                    </div>
                  </div>  
                      <div class="col">
                         <div alight ='left'>
                        <label class="form-label"> Module Code</label>
                        <input type='cell' class='form-control' placeholder="module code" value='<%=rs.getString("module_id") %>' name='moduleid' id="moduleid" required> 
                    </div>
                      </div>
             </div>
               <div class="row">
                <div class="col">
                    <div alight ='left'>
                        <label class="form-label"> Course</label>
                        <input type='text' class='form-control' placeholder="course" value='<%=rs.getString("course") %>' name='course' id="course" required> 
                    </div>
                </div>
                 <div class="col">                    
                    <div alight ='left'>
                        <label class="form-label"> Amount Paid</label>
                        <input type='text' class='form-control' placeholder="amount" value='<%=rs.getString("amount") %>' name='amount' id="amount" required> 
                    </div>
                 </div>
               </div>                                                                                                          
                    <%
                     }
                     %> 
                     </br>
                    <div alight ='right'>
                        <input type="submit" id="submit" value="submit" name="submit" class='btn btn-info'>
                        <input type="reset" id="reset" value="reset" name="reset" class='btn btn-warning'>
                    </div>       
                </form>
        </div>
          </div>
           </div>
    </div>
    </body>
</html>
